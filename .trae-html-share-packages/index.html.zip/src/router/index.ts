import { watch } from 'vue'
import { createRouter, createWebHashHistory } from 'vue-router'
import type { RouteLocationNormalizedLoadedGeneric } from 'vue-router'
import SiteLayout from '@/layouts/SiteLayout.vue'
import Home from '@/views/Home.vue'
import LegalView from '@/views/LegalView.vue'
import { locale, type Locale } from '@/i18n'

// 页面标题与描述按 locale 计算
type LocaleText = Record<Locale, string>

// TODO: 上线前替换为正式域名（canonical / OG / sitemap 均依赖它）
export const SITE_URL = 'https://kinhealth.example.com'

const router = createRouter({
  // hash 模式：打包成单文件后可直接用 file:// 打开
  history: createWebHashHistory(),
  routes: [
    {
      path: '/',
      component: SiteLayout,
      children: [
        {
          path: '',
          name: 'Home',
          component: Home,
          meta: {
            title: {
              zh: 'KinHealth · 家庭健康记录，只留在这台 iPhone',
              en: 'KinHealth · Family health records that stay on your iPhone',
            } satisfies LocaleText,
            description: {
              zh: 'KinHealth 是一款 iPhone 家庭健康记录工具：慢病档案、趋势图、用药提醒与就诊计划。数据只保存在本机，不收集、不上传、无广告。',
              en: 'KinHealth is a family health records app for iPhone: chronic condition profiles, trends, medication reminders and care plans. Data stays on device — no account, no server, no ads.',
            } satisfies LocaleText,
          },
        },
        {
          path: 'privacy',
          name: 'Privacy',
          component: LegalView,
          props: { kind: 'privacy' },
          meta: {
            title: { zh: '隐私政策 · KinHealth', en: 'Privacy Policy · KinHealth' } satisfies LocaleText,
            description: {
              zh: 'KinHealth 隐私政策：不接入统计与广告 SDK，全部数据仅保存在设备上的应用沙盒内，开发者无法访问。',
              en: 'KinHealth privacy policy: no analytics or ad SDKs, all data stays in the on-device app sandbox and is never accessible to the developer.',
            } satisfies LocaleText,
          },
        },
        {
          path: 'terms',
          name: 'Terms',
          component: LegalView,
          props: { kind: 'terms' },
          meta: {
            title: { zh: '服务条款 · KinHealth', en: 'Terms of Service · KinHealth' } satisfies LocaleText,
            description: {
              zh: 'KinHealth 服务条款：个人与家庭健康信息记录工具，不是医疗器械，不提供诊断或用药建议。',
              en: 'KinHealth terms of service: a personal and family health record tool, not a medical device, and does not provide diagnosis or medical advice.',
            } satisfies LocaleText,
          },
        },
      ],
    },
  ],
})

// 按当前 locale 解析页面文案
function routeText(to: RouteLocationNormalizedLoadedGeneric, key: 'title' | 'description'): string {
  const text = to.meta[key] as LocaleText | undefined
  return text ? text[locale.value] : key === 'title' ? 'KinHealth' : ''
}

// 更新 <meta> 标签（name 或 property 两类）
function setMeta(attr: 'name' | 'property', key: string, content: string) {
  let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${key}"]`)
  if (!el) {
    el = document.createElement('meta')
    el.setAttribute(attr, key)
    document.head.appendChild(el)
  }
  el.setAttribute('content', content)
}

function syncMeta(to: RouteLocationNormalizedLoadedGeneric) {
  const title = routeText(to, 'title')
  const description = routeText(to, 'description')
  const url = `${SITE_URL}/${to.fullPath === '/' ? '' : `#${to.fullPath}`}`

  document.title = title
  setMeta('name', 'description', description)
  setMeta('property', 'og:title', title)
  setMeta('property', 'og:description', description)
  setMeta('property', 'og:url', url)
  setMeta('property', 'og:locale', locale.value === 'zh' ? 'zh_CN' : 'en_US')
}

router.afterEach(syncMeta)

// locale 切换时同步标题与 meta
watch(locale, () => syncMeta(router.currentRoute.value))

export default router
