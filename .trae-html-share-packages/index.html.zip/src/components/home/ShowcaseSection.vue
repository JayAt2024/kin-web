<script setup lang="ts">
import { computed } from 'vue'
import PhoneFrame from '@/components/site/PhoneFrame.vue'
import { useCopy } from '@/i18n'
import recordsShot from '@/assets/screenshots/zh-02-records.png'
import plansShot from '@/assets/screenshots/zh-03-plans.png'
import settingsShot from '@/assets/screenshots/zh-04-settings.png'

const t = useCopy()

// 截图与倾斜角度与语言无关，保留在组件内
const shots = [recordsShot, plansShot, settingsShot]
const tilts = [-3, 0, 3]

const screens = computed(() =>
  t.value.showcase.screens.map((screen, index) => ({
    ...screen,
    index: String(index + 1).padStart(2, '0'),
    src: shots[index],
    tilt: tilts[index],
  })),
)
</script>

<template>
  <section class="showcase section">
    <div class="container">
      <div class="showcase__head">
        <span class="eyebrow">SCREENS</span>
        <h2 class="display display-lg showcase__title">{{ t.showcase.titleLine1 }}<br />{{ t.showcase.titleLine2 }}</h2>
        <p class="lead showcase__lead">
          {{ t.showcase.lead }}
        </p>
      </div>

      <div class="showcase__grid">
        <figure v-for="screen in screens" :key="screen.index" class="screen">
          <span class="screen__index mono">{{ screen.index }}</span>
          <div class="screen__device">
            <PhoneFrame :src="screen.src" :alt="screen.alt" width="100%" :tilt="screen.tilt" />
          </div>
          <figcaption>
            <h3>{{ screen.title }}</h3>
            <p>{{ screen.desc }}</p>
          </figcaption>
        </figure>
      </div>
    </div>
  </section>
</template>

<style scoped>
.showcase {
  background: var(--paper-soft);
  border-top: 1px solid var(--line);
  border-bottom: 1px solid var(--line);
}

.showcase__head {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  padding-bottom: 64px;
}

.showcase__title {
  margin-top: 22px;
}

.showcase__lead {
  max-width: 540px;
  margin-top: 18px;
  font-size: 15px;
  color: var(--muted);
}

.showcase__grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 48px;
  align-items: start;
}

.screen {
  margin: 0;
}

.screen__index {
  display: block;
  padding-bottom: 12px;
  border-bottom: 1px solid var(--line);
  color: var(--muted);
}

.screen__device {
  margin-block: 26px 22px;
  padding-inline: 10%;
}

.screen:nth-child(2) .screen__device {
  padding-top: 34px;
}

.screen figcaption h3 {
  font-family: var(--font-display);
  font-size: 20px;
  font-weight: 600;
}

.screen figcaption p {
  margin-top: 8px;
  font-size: 13px;
  line-height: 1.8;
  color: var(--muted);
}

@media (max-width: 960px) {
  .showcase__grid {
    grid-template-columns: 1fr;
    gap: 40px;
    max-width: 380px;
    margin-inline: auto;
  }

  .screen__device {
    padding-inline: 0;
  }

  .screen:nth-child(2) .screen__device {
    padding-top: 0;
  }

  .showcase__head {
    padding-bottom: 44px;
  }
}
</style>
